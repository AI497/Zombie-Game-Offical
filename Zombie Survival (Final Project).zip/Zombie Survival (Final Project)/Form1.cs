﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zombie_Survival__Final_Project_
{
    public partial class Form1 : Form
    {


        // Movement flags
        bool moveUp = false;
        bool moveDown = false;
        bool moveLeft = false;
        bool moveRight = false;
        
        int moveSpeed = 5; //speed of the player

        int bulletspeed = 25; //speed of the bullet
        
        bool bulletStart = false; //variable to start the bullet

        int[] zombieHealth = new int[4] { 1, 1, 1 , 1}; //array with health of each zombie

        string soldierDirection = "right";  //variable to check the soldier's direction

        int soldierHealth = 50; //variable for soldier health


        bool hit = false; //variable to check when a zombie is hit


        bool shoot = false; //variable to check when the bullet is shot.

        int currentLevel = 1; //variable for the player's level


        PictureBox[] zombies = new PictureBox[4]; //Array for zombies.

        int zombieNum; //number of zombies

        Point[] zombieStartPositions = new Point[4]; //variable to store each zombie's starting position so they can return after each level

        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;

            //assign the blocks on the screen to the array blocks

            zombies[0] = zombi; //assigning zombies in the arrays
            zombies[1] = zombi2;
            zombies[2] = zombi3;
            zombies[3] = zombi4;

            zombieNum = zombies.Length;

            for (int i = 0; i < zombies.Length; i++) 
            {
                zombieStartPositions[i] = zombies[i].Location;
            }

            


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // Update movements based on which key is pressed

            if (e.KeyCode == Keys.Up) moveUp = true;
            if (e.KeyCode == Keys.Down) moveDown = true;
            if (e.KeyCode == Keys.Left) moveLeft = true;
            if (e.KeyCode == Keys.Right) moveRight = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            

            bullet.Visible = false; //makes the bullet invisible when the game starts
            
            if (moveUp)Solider.Top -= moveSpeed; //if up arrow is pressed solider moves up
            if (moveDown) Solider.Top += moveSpeed; //if up arrow is pressed solider moves down
            
            if (moveLeft) //if left arrow is pressed solider moves left and the image changes so that the solider is facing that direction
            {
                Solider.Left -= (moveSpeed);
                Solider.Image = Image.FromFile("Soldier-Left.png");
                soldierDirection = "left";
            }
            if (moveRight) //if right arrow is pressed solider moves right and the image changes so that the solider is facing that direction
            {
                Solider.Left += moveSpeed;
                Solider.Image = Image.FromFile("Soldier-Right.png");
                soldierDirection = "right";
            }

            for (int i = 0; i < zombies.Length; i++) //code for all the zombies.
            {
                if (!zombies[i].Visible) continue; // Skip dead zombies

                if (Math.Abs(Solider.Left - zombies[i].Left) < 400) //if the player is within the zombies range, the code will start
                {

                    zombies[i].Image = Image.FromFile("zombie_newchar_left.png");

                    // Move zombie toward player
                    if (zombies[i].Left < Solider.Left)
                    {
                        zombies[i].Left += 2;
                        
                    }

                    else if (zombies[i].Left > Solider.Left)
                        zombies[i].Left -= 2;

                    if (zombies[i].Top < Solider.Top)
                        zombies[i].Top += 2;

                    else if (zombies[i].Top > Solider.Top)
                        zombies[i].Top -= 2;

                    // Check collision with player
                    if (zombies[i].Bounds.IntersectsWith(Solider.Bounds))
                    {

                        hit = true;

                        if (hit)
                        {
                            soldierHealth--; //reduces player's health if the zombie is touching the soldier
                            hit = false; //makes it false so that it doesn't immideately kill the player
                            health.Text = Convert.ToString(soldierHealth); 

                            

                            //changes color of health bar depending on the soldier's current health

                            if (soldierHealth == 30) 
                            {

                                label1.BackColor = Color.Orange;
                                health.BackColor = Color.Orange;

                            }

                            if (soldierHealth == 15)
                            {

                                label1.BackColor = Color.OrangeRed;
                                health.BackColor = Color.OrangeRed;

                            }


                            if (soldierHealth == 0) //soldier dies
                            {
                                label1.BackColor = Color.Red;
                                health.BackColor = Color.Red;
                                Solider.Image = Image.FromFile("Soldier-Dead.png");
                                timer1.Enabled = false;
                                MessageBox.Show($"You are dead!\nYou reached Area {currentLevel}");


                            }

                        }

                    }
                }
            }

            if (shoot == true) //shoot is true when the mouse button is pressed.
            {
                bool hitZombie = false; //variable to check if the bullet touches a zombie or not

                for (int i = 0; i < zombies.Length; i++) //code for each zombie
                {
                    if (!zombies[i].Visible) continue; //if zombie is invisible it means they are dead already, and the bullets will go over them

                    if (bullet.Bounds.IntersectsWith(zombies[i].Bounds)) //if zombie and bullets intersect
                    {
                        zombieHealth[i] -= 1; //zombie's health will go down by 1
                        shoot = false; //shoot will be false so that it doesn't immideately kill the zombie, after touching it
                        bullet.Visible = false; //bullet will be invisible
                        hitZombie = true; 

                        if (zombieHealth[i] <= 0) //when zombie dies
                        {
                            zombies[i].Visible = false;
                            zombieNum--;
                            
                        }
                        break; // Only one zombie gets hit per bullet
                    }
                }

                // Move bullet only if it didn’t hit anything
                if (!hitZombie) 
                {
                    bullet.Left += bulletspeed;
                    bullet.Visible = true;

                    if (bullet.Left > this.Width)
                    {
                        shoot = false;
                        bullet.Visible = false;
                    }
                }
            }

            if (zombieNum == 0) //variable for going to different levels
            {
                timer1.Enabled = false; //disables timers so that zombies do not appear and start killing the player

                currentLevel++;
                levelInt.Text = currentLevel.ToString(); 

                MessageBox.Show("Section Cleared!");

                if (currentLevel % 2 == 0) //every 2 levels, reset health
                {
                    soldierHealth = 50;
                    label1.BackColor = Color.Green;
                    health.BackColor = Color.Green;
                    health.Text = Convert.ToString(50);
                }



                // Reset zombies: make visible and restore health
                for (int i = 0; i < zombies.Length; i++)
                    {
                    zombies[i].Visible = true;
                    zombies[i].Location = zombieStartPositions[i];

                    

                }

                zombieNum = zombies.Length;

                

                for (int x = 0; x < zombieHealth.Length; x++)
                {
                    zombieHealth[x] = currentLevel;
                }



                timer1.Enabled = true; //starts the game once again
            }







        }

        private void Form1_KeyUp_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up) moveUp = false;
            if (e.KeyCode == Keys.Down) moveDown = false;
            if (e.KeyCode == Keys.Left) moveLeft = false;
            if (e.KeyCode == Keys.Right) moveRight = false;
        }

        private void zombi_Click(object sender, EventArgs e)
        {

        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (soldierDirection == "right") //if direction of soldier is right
            {
                bullet.Left = Solider.Left + Solider.Width;
                bulletspeed = Math.Abs(bulletspeed); // ensure bullet goes right
            }
            else
            {
                bullet.Left = Solider.Left - bullet.Width;
                bulletspeed = -Math.Abs(bulletspeed); // ensure bullet goes left
            }

            bullet.Top = Solider.Top + (Solider.Height / 2);
            bullet.Visible = true;
            shoot = true;

        }

        private void Stage1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(this); //hides this form first so that the title screen can show up
            form2.Show();
            this.Hide();
        }


    }
}
