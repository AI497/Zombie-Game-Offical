﻿namespace Zombie_Survival__Final_Project_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Solider = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bullet = new System.Windows.Forms.PictureBox();
            this.zombi2 = new System.Windows.Forms.PictureBox();
            this.zombi3 = new System.Windows.Forms.PictureBox();
            this.zombi = new System.Windows.Forms.PictureBox();
            this.zombi4 = new System.Windows.Forms.PictureBox();
            this.health = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Stage1 = new System.Windows.Forms.Label();
            this.levelInt = new System.Windows.Forms.Label();
            this.restTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Solider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bullet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombi2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombi3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombi4)).BeginInit();
            this.SuspendLayout();
            // 
            // Solider
            // 
            this.Solider.BackColor = System.Drawing.Color.Transparent;
            this.Solider.Image = ((System.Drawing.Image)(resources.GetObject("Solider.Image")));
            this.Solider.Location = new System.Drawing.Point(-1, 467);
            this.Solider.Name = "Solider";
            this.Solider.Size = new System.Drawing.Size(96, 155);
            this.Solider.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Solider.TabIndex = 0;
            this.Solider.TabStop = false;
            this.Solider.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // bullet
            // 
            this.bullet.BackColor = System.Drawing.Color.Transparent;
            this.bullet.Image = ((System.Drawing.Image)(resources.GetObject("bullet.Image")));
            this.bullet.Location = new System.Drawing.Point(100, 361);
            this.bullet.Name = "bullet";
            this.bullet.Size = new System.Drawing.Size(26, 10);
            this.bullet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bullet.TabIndex = 2;
            this.bullet.TabStop = false;
            // 
            // zombi2
            // 
            this.zombi2.BackColor = System.Drawing.Color.Transparent;
            this.zombi2.Image = ((System.Drawing.Image)(resources.GetObject("zombi2.Image")));
            this.zombi2.Location = new System.Drawing.Point(900, 188);
            this.zombi2.Name = "zombi2";
            this.zombi2.Size = new System.Drawing.Size(71, 152);
            this.zombi2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.zombi2.TabIndex = 3;
            this.zombi2.TabStop = false;
            // 
            // zombi3
            // 
            this.zombi3.BackColor = System.Drawing.Color.Transparent;
            this.zombi3.Image = ((System.Drawing.Image)(resources.GetObject("zombi3.Image")));
            this.zombi3.Location = new System.Drawing.Point(534, 470);
            this.zombi3.Name = "zombi3";
            this.zombi3.Size = new System.Drawing.Size(71, 152);
            this.zombi3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.zombi3.TabIndex = 4;
            this.zombi3.TabStop = false;
            // 
            // zombi
            // 
            this.zombi.BackColor = System.Drawing.Color.Transparent;
            this.zombi.Image = ((System.Drawing.Image)(resources.GetObject("zombi.Image")));
            this.zombi.Location = new System.Drawing.Point(254, 65);
            this.zombi.Name = "zombi";
            this.zombi.Size = new System.Drawing.Size(71, 152);
            this.zombi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.zombi.TabIndex = 1;
            this.zombi.TabStop = false;
            this.zombi.Click += new System.EventHandler(this.zombi_Click);
            // 
            // zombi4
            // 
            this.zombi4.BackColor = System.Drawing.Color.Transparent;
            this.zombi4.Image = ((System.Drawing.Image)(resources.GetObject("zombi4.Image")));
            this.zombi4.Location = new System.Drawing.Point(686, 65);
            this.zombi4.Name = "zombi4";
            this.zombi4.Size = new System.Drawing.Size(71, 152);
            this.zombi4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.zombi4.TabIndex = 5;
            this.zombi4.TabStop = false;
            // 
            // health
            // 
            this.health.AutoSize = true;
            this.health.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.health.Font = new System.Drawing.Font("MS UI Gothic", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.health.Location = new System.Drawing.Point(148, 24);
            this.health.Name = "health";
            this.health.Size = new System.Drawing.Size(57, 40);
            this.health.TabIndex = 6;
            this.health.Text = "50";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 40);
            this.label1.TabIndex = 7;
            this.label1.Text = "Health:";
            // 
            // Stage1
            // 
            this.Stage1.AutoSize = true;
            this.Stage1.BackColor = System.Drawing.Color.Transparent;
            this.Stage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stage1.ForeColor = System.Drawing.Color.Green;
            this.Stage1.Location = new System.Drawing.Point(923, 574);
            this.Stage1.Name = "Stage1";
            this.Stage1.Size = new System.Drawing.Size(115, 46);
            this.Stage1.TabIndex = 8;
            this.Stage1.Text = "Area:";
            this.Stage1.Click += new System.EventHandler(this.Stage1_Click);
            // 
            // levelInt
            // 
            this.levelInt.AutoSize = true;
            this.levelInt.BackColor = System.Drawing.Color.Transparent;
            this.levelInt.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.levelInt.ForeColor = System.Drawing.Color.Green;
            this.levelInt.Location = new System.Drawing.Point(1023, 574);
            this.levelInt.Name = "levelInt";
            this.levelInt.Size = new System.Drawing.Size(42, 46);
            this.levelInt.TabIndex = 9;
            this.levelInt.Text = "1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1070, 622);
            this.Controls.Add(this.levelInt);
            this.Controls.Add(this.Stage1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.health);
            this.Controls.Add(this.zombi4);
            this.Controls.Add(this.zombi3);
            this.Controls.Add(this.zombi2);
            this.Controls.Add(this.bullet);
            this.Controls.Add(this.zombi);
            this.Controls.Add(this.Solider);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp_1);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.Solider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bullet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombi2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombi3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombi4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Solider;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox bullet;
        private System.Windows.Forms.PictureBox zombi2;
        private System.Windows.Forms.PictureBox zombi3;
        private System.Windows.Forms.PictureBox zombi;
        private System.Windows.Forms.PictureBox zombi4;
        private System.Windows.Forms.Label health;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Stage1;
        private System.Windows.Forms.Label levelInt;
        private System.Windows.Forms.Timer restTimer;
    }
}

