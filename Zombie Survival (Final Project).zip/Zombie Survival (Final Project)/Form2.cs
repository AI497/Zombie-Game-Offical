﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zombie_Survival__Final_Project_
{
    public partial class Form2 : Form
    {

        private Form1 mainGame;

        public Form2(Form1 form1)
        {
            InitializeComponent();
            mainGame = form1;

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void playButton_Click(object sender, EventArgs e)
        {
            this.Close();
            mainGame.Show(); // Show Form1 again
            
        }
    }
}
